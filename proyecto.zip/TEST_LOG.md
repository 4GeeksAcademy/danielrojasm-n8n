# Registro de pruebas — SnackCheck v1.0.0

**Entorno:** n8n (URL de test `/webhook-test/nutrition-check`) · **Fecha:** 2026-10-26 · **Probado por:** _tu nombre_

> Los valores nutricionales esperados son aproximados según Open Food Facts y pueden cambiar si la comunidad edita el producto. Completa la columna «Resultado obtenido» con lo que veas al ejecutar cada caso y marca ✅ / ❌.

## Pruebas funcionales

| ID | Descripción | Entrada | Resultado esperado | Resultado obtenido | Estado |
|---|---|---|---|---|---|
| TC-001 | Producto no saludable (Nutri-Score E, 2 altos) | `{"barcode":"3017620422003"}` (Nutella) | 200 `text/plain`. Azúcar 🔴 alto, grasa 🔴 alto, sal 🟢. Semáforo «no saludable», Nutri-Score «no saludable» → nivel **no saludable**. Preocupación 2/3. Titular ⚠️, tono cauteloso. | | |
| TC-002 | Gaseosa: semáforo «saludable» pero Nutri-Score malo | `{"barcode":"5449000000996"}` (Coca-Cola) | Azúcar ≈10.6 g → medio 🟢, sal y grasa 🟢. Semáforo «saludable», Nutri-Score E → nivel **no saludable** (gana el peor). Preocupación 0/3. Tono cauteloso. | | |
| TC-003 | Producto con Nutri-Score A | `{"barcode":"8076800195057"}` (Barilla Spaghetti n.º 5, verificar grado en OFF) | Las tres marcas 🟢, nivel **saludable**, preocupación 0/3, titular ✅, tono alentador. | | |
| TC-004 | Respaldo con Nutri-Score `unknown` | Producto real con `nutriscore_grade` = unknown (o datos fijados con *Pin data*: sal 2.1, azúcar 4, grasa 3) | Lectura Nutri-Score «desconocido» → se usa solo semáforo: 1 alto → **moderado**, tono alentador con matiz. | | |

## Pruebas de integración

| ID | Descripción | Entrada | Resultado esperado | Resultado obtenido | Estado |
|---|---|---|---|---|---|
| TC-005 | Llamada en vivo a Open Food Facts | TC-001 | El nodo HTTP muestra `statusCode: 200`, `body.status: 1` y solo los campos pedidos en `fields`. | | |
| TC-006 | Extracción con notación de corchetes | TC-001 | `energy_kcal_100g` ≈ 539 en la salida de `Set - Extract Product Fields` (no `null`). | | |
| TC-007 | Llamada en vivo a Groq por ambas rutas | TC-001 y TC-003 | Se ejecuta solo la rama de IA correspondiente; el Merge pasa un ítem con `text` no vacío. | | |

## Pruebas de error

| ID | Descripción | Entrada | Resultado esperado | Resultado obtenido | Estado |
|---|---|---|---|---|---|
| TC-008 | Cuerpo vacío | sin cuerpo / `{}` | 200 JSON de autodocumentación con `required_fields` y `example_request`. | | |
| TC-009 | Falta el campo barcode | `{"codigo":"123"}` | 400 JSON `invalid_barcode`, mensaje «Falta el campo barcode», ejemplo. | | |
| TC-010 | Barcode no numérico | `{"barcode":"abc-123"}` | 400 JSON `invalid_barcode`, mensaje «solo números», `received: "abc-123"`. | | |
| TC-011 | Producto inexistente | `{"barcode":"0000000000000"}` | OFF responde 404 / `status: 0`; el flujo no falla; 404 JSON `product_not_found` con ejemplo. | | |
| TC-012 | Producto sin datos de nutrición | Código real sin nutrientes en OFF (o *Pin data* en el nodo HTTP con `nutriments: {}`) | 200 JSON `insufficient_data` con `missing_fields`; **no** se genera veredicto ni se llama a la IA. | | |

## Rendimiento

| ID | Descripción | Método | Resultado esperado | Resultado obtenido | Estado |
|---|---|---|---|---|---|
| TC-013 | Tiempo de respuesta de extremo a extremo | 5 ejecuciones de TC-001; revisar la duración en *Executions* | Promedio < 4 s (OFF ≈ 0.3–1 s, Groq ≈ 0.5–2 s). Las respuestas de error responden en < 1.5 s porque no llaman a la IA. | | |

**Nota de rendimiento:** el cuello de botella esperado es la llamada a la IA. Pedir solo los campos necesarios a Open Food Facts mantiene la respuesta pequeña, y el timeout de 10 s evita esperas indefinidas.
